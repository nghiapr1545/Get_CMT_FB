FLASK_APP=../src/fb_comment_downloader_app.py flask run
