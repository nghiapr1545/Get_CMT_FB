systemctl stop fb-comment-downloader.service
